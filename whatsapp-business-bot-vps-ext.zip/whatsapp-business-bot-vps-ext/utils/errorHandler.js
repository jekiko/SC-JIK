module.exports = {
  handle: (err) => {
    console.error('[FATAL]', err);
    // Optionally implement restart logic or notification
  }
};
