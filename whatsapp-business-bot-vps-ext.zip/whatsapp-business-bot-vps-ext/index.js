const { Client, LocalAuth } = require('whatsapp-web.js');
const fs = require('fs');
const path = require('path');
const config = require('config');
const logger = require('./utils/logger');
const errorHandler = require('./utils/errorHandler');

const client = new Client({
  authStrategy: new LocalAuth({ clientId: 'business_bot_vps_ext' }),
  puppeteer: { headless: true }
});

process.on('unhandledRejection', errorHandler.handle);
process.on('uncaughtException', errorHandler.handle);

const modulesDir = path.join(__dirname, 'modules');
fs.readdirSync(modulesDir).forEach(file => {
  if (file.endsWith('.js')) {
    try {
      require(path.join(modulesDir, file))(client);
    } catch (e) {
      logger.error(`Module ${file} failed: ${e.message}`);
    }
  }
});

client.on('ready', () => {
  logger.info('Bot siap dijalankan (VPS Extended)!');
});

client.initialize();
