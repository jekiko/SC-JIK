module.exports = client => {
  client.on('message', async msg => {
    if (msg.body.startsWith('!remind')) {
      // format: !remind|HH:MM|Pesan
      const [_, time, text] = msg.body.split('|');
      const [h, m] = time.split(':').map(Number);
      const now = new Date();
      const target = new Date();
      target.setHours(h, m, 0);
      const delay = target - now;
      if (delay > 0) {
        setTimeout(() => msg.reply(`Reminder: ${text}`), delay);
        msg.reply(`Pengingat diatur pukul ${time}`);
      } else {
        msg.reply('Waktu sudah lewat.');
      }
    }
  });
};