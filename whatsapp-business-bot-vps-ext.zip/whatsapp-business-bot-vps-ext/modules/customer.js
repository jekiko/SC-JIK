const MongoClient = require('mongodb').MongoClient;
const config = require('config');
module.exports = client => {
  client.on('message', async msg => {
    if (msg.body.startsWith('!addcustomer')) {
      const [_, name, phone] = msg.body.split('|');
      const db = await MongoClient.connect(config.get('database.url'));
      await db.db().collection(config.get('database.customersCollection'))
        .insertOne({ name: name.trim(), phone: phone.trim() });
      msg.reply(`Pelanggan ${name.trim()} ditambahkan.`);
      db.close();
    }
  });
};