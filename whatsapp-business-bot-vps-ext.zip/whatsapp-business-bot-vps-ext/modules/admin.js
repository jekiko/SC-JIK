module.exports = client => {
  client.on('message', async msg => {
    if (msg.body === '!stats') {
      await msg.reply('Bot berjalan dengan normal.');
    }
  });
};