const config = require('config');
module.exports = client => {
  client.on('message', async msg => {
    if (msg.body.startsWith('!pay')) {
      // stub integrasi Midtrans
      msg.reply('Link pembayaran: https://payment.gateway/');
    }
  });
};