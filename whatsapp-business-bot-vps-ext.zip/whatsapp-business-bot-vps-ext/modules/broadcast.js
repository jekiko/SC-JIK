module.exports = client => {
  client.on('message', async msg => {
    if (msg.body.startsWith('!broadcast')) {
      const text = msg.body.split(' ').slice(1).join(' ');
      // contoh: kirim ke semua pelanggan (in-mem)
      msg.reply('Broadcast terkirim: ' + text);
    }
  });
};