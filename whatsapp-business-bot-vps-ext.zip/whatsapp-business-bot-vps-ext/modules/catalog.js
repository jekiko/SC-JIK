module.exports = client => {
  client.on('message', async msg => {
    if (msg.body === '!catalog') {
      const items = [
        { name: 'Produk A', price: 'Rp50k' },
        { name: 'Produk B', price: 'Rp75k' }
      ];
      let reply = 'Katalog:';
      items.forEach(i => reply += `\n${i.name} - ${i.price}`);
      await msg.reply(reply);
    }
  });
};