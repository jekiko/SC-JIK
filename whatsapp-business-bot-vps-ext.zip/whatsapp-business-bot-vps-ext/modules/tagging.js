module.exports = client => {
  client.on('message', async msg => {
    if (msg.body.startsWith('!tagall')) {
      const chat = await msg.getChat();
      if (chat.isGroup) {
        const mentions = chat.participants.map(u => u.id._serialized);
        chat.sendMessage('Attention:", { mentions });
      }
    }
  });
};