module.exports = client => {
  client.on('message', async msg => {
    const text = msg.body.toLowerCase();
    if (text.includes('halo') || text.includes('hi')) {
      await msg.reply('Halo! Ada yang bisa kami bantu?');
    }
  });
};