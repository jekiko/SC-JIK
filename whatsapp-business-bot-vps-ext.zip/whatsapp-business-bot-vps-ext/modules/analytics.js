module.exports = client => {
  let count = 0;
  client.on('message', () => { count++; });
  client.on('message', async msg => {
    if (msg.body === '!analytics') {
      msg.reply(`Total pesan diproses: ${count}`);
    }
  });
};