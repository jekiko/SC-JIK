module.exports = client => {
  let subs = [];
  client.on('message', async msg => {
    if (msg.body === '!subscribe') {
      subs.push(msg.from);
      msg.reply('Berhasil subscribe!');
    } else if (msg.body === '!unsubscribe') {
      subs = subs.filter(u => u !== msg.from);
      msg.reply('Berhasil unsubscribe!');
    }
  });
};