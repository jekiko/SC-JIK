#!/bin/bash
curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
apt update && apt install -y nodejs git mongodb

git clone https://github.com/username/whatsapp-business-bot-vps-ext.git /home/container
cd /home/container
npm install
npm start
